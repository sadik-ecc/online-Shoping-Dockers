import { generateProducts } from './productData';

export const demoProducts = generateProducts(); 